# Parking > 2023-11-24 12:00am
https://universe.roboflow.com/tesis-3c464/parking-8lvoy

Provided by a Roboflow user
License: CC BY 4.0

